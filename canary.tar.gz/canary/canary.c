#include <stdint.h>
#include <string.h>

int f(uint8_t *dest, uint8_t *src, size_t len) {
	memcpy(dest, src, len);
	return dest == NULL;
}
